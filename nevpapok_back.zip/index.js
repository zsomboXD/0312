import express from 'express'
import cors from 'cors'
import mysql from 'mysql2/promise.js'
import { configDB } from './configDB.js'
const PORT = 8000

let connection
try {
    connection = await mysql.createConnection(configDB)
} catch (error) {
    console.log(error);

}

const app = express()
app.use(express.json())
app.use(cors())

app.get('/api/name_days', async (req, resp) => {
    try {
        const sql = "SELECT * FROM `name_days` WHERE 1"
        const [rows, fields] = await connection.execute(sql)
        resp.status(200).send(rows)
    } catch (error) {
        console.log(error);

    }

})

app.get('/api/names/:day/:month', async (req, resp) => {
    const {day, month}=req.params
    try {
        const sql = "SELECT name FROM name_days WHERE day=? AND month=?"
        const [rows, fields] = await connection.query(sql,[day,month])
        resp.status(200).send(rows)
    } catch (error) {
        console.log(error);

    }
})

app.get('/api/dates/:name', async (req, resp) => {
    const {name}=req.params
    try {
        const sql = "SELECT day,month FROM name_days WHERE name=? ORDER BY month asc"
        const [rows, fields] = await connection.query(sql,[name])
        if (rows.length > 0) resp.status(200).send(rows)
            else resp.status(404).json({ msg: "Nincs találat!" })
        resp.status(200).send(rows)
    } catch (error) {
        console.log(error);

    }
})

app.get('/api/info/:name', async (req, resp) => {
    const {name}=req.params
    try {
        const sql = "SELECT * from name_info where name_info.name=?"
        const [rows, fields] = await connection.query(sql,[name])
        if (rows.length > 0) resp.status(200).send(rows)
            else resp.status(404).json({ msg: "Nincs találat!" })
        resp.status(200).send(rows)
    } catch (error) {
        console.log(error);

    }
})

app.delete('/api/info/:name', async (req, resp) => {
    const {name}=req.params
    try {
        const sql = "DELETE from name_info where name=?"
        const [rows, fields] = await connection.query(sql,[name])
        if (result.affectedRows == 0) return resp.status(404).json({ msg: "Nincs találat!" })
            //törli de nem irja ki xdxdddddd
            else resp.status(200).json({ msg: 'Sikeres törlés!' })
        } catch (error) {
            console.log(error);
            resp.status(500).json({ msg: error })
        }
})

app.post('/api/property', async (req, resp) => {
    const { kategoriaId, leiras, hirdetesDatuma, tehermentes, ar, kepUrl } = req.body
    try {
        const sql = "INSERT INTO ingatlanok (kategoriaId, leiras, hirdetesDatuma, tehermentes, ar, kepUrl) VALUES (?, ?, ?, ?, ?, ?)";
        const [rows, fields] = await connection.query(sql, [kategoriaId, leiras, hirdetesDatuma, tehermentes, ar, kepUrl])
        resp.status(201).json({ msg: 'Sikeres hozzadas!' })

    } catch (error) {
        console.log(error);
        resp.status(500).json({ msg: error })
    }
});

app.listen(PORT, () => console.log(`server listening on port: ${PORT}`))
