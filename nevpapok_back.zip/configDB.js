export const configDB={
    host:'localhost',
    user:'root',
    password:'',
    database:'nevnapok',
    multipleStatements:true
}