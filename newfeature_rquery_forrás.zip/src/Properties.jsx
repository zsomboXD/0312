import React from 'react'
import { getData } from './utils'
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FaHouse } from 'react-icons/fa6';
import noImage from './assets/noimage2.jpg'
import { useState } from 'react';
const url = "http://localhost:8000/api/property";
const url_ctg = "http://localhost:8000/api/categories/"
const base_url = "http://localhost:8000/api/property";


export const Properties = () => {
  const [showCateg,setShowCateg]=useState(false)
  const [fromDate,setFromDate]=useState('')
  const [url,setUrl]=useState(base_url)

  const { data,isLoading, isError,error } = useQuery({queryKey:['properties', url],queryFn:getData});
  const { data:dataCtg,isLoading:isLoadingCtg, isError:isErrorCtg,error:errorCtg } = useQuery({queryKey:['categories', url_ctg,showCateg],queryFn:getData,enabled:!!showCateg});
  const navigate=useNavigate()

  if (isLoading) return <div>loading...</div>
  if (isError)  return <div>{error.response?.data?.msg}</div>;
  data && console.log(data);

  const handleImageError = (event) => {
    event.target.src = noImage; // Alapértelmezett kép betöltése
  };
  const handleFiltering=()=>{
    if(!fromDate) return
    console.log(fromDate,typeof fromDate);
    const dateArr=fromDate.split('-')
    console.log('hónap:',dateArr[1]);
    console.log('nap:',dateArr[2]);
    //const nap=dateArr[2]
    const [year,month,day]=dateArr
    console.log(year,month,day);
    setUrl(base_url+'/from/'+fromDate)
    
  }


  return (
  <div className="container offers">

<div className='form-group'>
  <label className='form-label'>Hirdetes</label>
  <input type="date" className='form-control' name='hirdetesDatuma' value={fromDate} onChange={(e)=>setFromDate(e.target.value)}/>
</div>
<div className='form-group text-center'>
  <button className='btn' onClick={handleFiltering}>asdasd</button>
</div>

      <FaHouse onClick={()=>navigate('/')} className='house'/>
      <h2 className="section-title">Aktuális ajánlataink</h2>
      <div className="listings-container">
      {data && data.map(obj=>
          <div className="listing-card" key={obj.id}>
            <div className="card-header">
                <span className="title">{obj.kategNev}</span>
                <span className="date">{obj.hirdetesDatuma.slice(0,10)}</span>
            </div>
            <img className="card-image" src={obj.kepUrl} alt="Ház"
            onError={handleImageError}
            />
            <div className="card-footer">
                <button className="btn " onClick={()=>navigate('/property/'+obj.id)}>Részletek</button>
            </div>
          </div>  

      )}    
      </div> 
      <button onClick={()=>setShowCateg(!showCateg)}>Kategorák listázása/eltünése</button>
      <ul>
            {dataCtg && dataCtg.map(obj=><li key={obj.id}>{ obj.nev}</li>)}
           </ul> 
    </div>                
  )
}


