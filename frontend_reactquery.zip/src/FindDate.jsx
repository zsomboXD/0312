import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getData } from './utils'
import { useQuery } from '@tanstack/react-query'

const base_url="http://localhost:8000/api/dates/"
const base_url_info="http://localhost:8000/api/info/"

export const FindDate = () => {
  const [url, setUrl] = useState(null)
  const [url_info, setUrl_info] = useState(null)

  const { error, data } = useQuery({
    queryKey: ['dates', url],
    queryFn: getData,
    enabled: !!url,
    retry:false
    //dömötör
  })

  const { error:error_info, data:data_info } = useQuery({
    queryKey: ['name_info', url_info],
    queryFn: getData,
    enabled: !!url_info && !!data,
    retry:false
  })

  const navigate=useNavigate()
  const [name, setName] = useState("")
  const handleClick=()=>{
    //console.log(dömötör)
    if (!name) return
    setUrl(base_url+name)
    setUrl_info(base_url_info+name)
    setName("")
  }

  data && console.log(data);
  error && console.log(error);
  data_info && console.log(data_info);
  
  
  return (

    <div>
      <button onClick={()=>navigate('/')}>HOME</button>
      <div>
        <input type="text" value={name} onChange={(e)=>setName(e.target.value)}/>
        
      </div>
      <button onClick={handleClick}>Keresés</button>
      <ul>
        {data && data.map(obj=>
          <li>
            {obj.day}-{obj.month}
          </li>
        )}
      </ul>
      {error && <div>{error.response.data.msg} </div > }
      {data_info && <p> {data_info[0].descr} </p>}
    </div>
  )
}
//dömötör
export default FindDate
