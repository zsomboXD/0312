import React from 'react'
import { useNavigate } from 'react-router-dom'

export const Home = () => {
  const navigate=useNavigate()

  return (
    <div>
      <h1>NÉVNAPKERESŐ</h1>
      <button onClick={()=>navigate('/findnames')}>Keresés Dátum szerint</button>
      <button onClick={()=>navigate('/finddates')}>Keresés Név szerint</button>
    </div>
  )
}

export default Home
