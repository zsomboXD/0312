import React from 'react'
import { useNavigate } from 'react-router-dom'

const base_url2="http://localhost:8000/api/dates/"
const base_url="http://localhost:8000/api/names/"

export const FindName = () => {
  const navigate=useNavigate()

  return (
    <div>
      <button onClick={()=>navigate('/')}>HOME</button>
      <div>
        <input type="date" />
        
      </div>
      <button >Keresés</button>
    </div>
  )
}

export default FindName
