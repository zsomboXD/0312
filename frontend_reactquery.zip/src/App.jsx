import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import {FindName} from './FindName'
import {FindDate} from './FindDate'
import {Home} from './Home'

const router=createBrowserRouter([
  {path:'/',element:<Home />},
  {path:'/findnames',element:<FindName />},
  {path:'/finddates',element:<FindDate />}
])

function App() {
 
  return <RouterProvider router={router}/>
}

export default App
