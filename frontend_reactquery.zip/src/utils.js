import axios from "axios";

export const getData=async ({queryKey})=>{
    const response=await axios.get(queryKey[1])
    return response.data
}

export const getNames=async (url,setNames)=>{
  try{
    const response=await axios.get(url)
    setNames(response.data)
    return response.data
  } catch (error) {
    console.log(error.response.data);
  }
}
